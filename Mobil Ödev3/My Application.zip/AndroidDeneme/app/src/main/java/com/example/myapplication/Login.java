package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Firebase;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity {

    Button loginButton, passwordReset;

    EditText usurname, password;
    FirebaseAuth mAuth;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginscreen);

        usurname = (EditText) findViewById(R.id.usurname_text);
        password = (EditText) findViewById(R.id.registerPassword_text);
        loginButton = (Button) findViewById(R.id.giris_button);
        passwordReset = (Button) findViewById(R.id.passwordReset_button);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail = usurname.getText().toString();
                String sifre = password.getText().toString();

                if (TextUtils.isEmpty(mail) || TextUtils.isEmpty(sifre)) {
                    Toast.makeText(Login.this, "Lütfen tüm alanları doldurun", Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.signInWithEmailAndPassword(mail, sifre)
                        .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    if (user != null && user.isEmailVerified()) {
                                        Toast.makeText(Login.this, "Başarıyla giriş yapıldı", Toast.LENGTH_SHORT).show();
                                        redirectToAppropriateActivity(user);
                                    } else {
                                        Toast.makeText(Login.this, "Mailinizi Doğrulayınız", Toast.LENGTH_SHORT).show();
                                        mAuth.signOut();
                                    }
                                } else {
                                    Toast.makeText(Login.this, "Giriş başarısız ", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .addOnFailureListener(Login.this, new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(Login.this, "Giriş başarısız. Lütfen bilgilerinizi kontrol ediniz", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        passwordReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this, PasswordReset.class);
                startActivity(intent);
            }
        });
    }

    private void redirectToAppropriateActivity(FirebaseUser user) {
        DatabaseReference mReference = FirebaseDatabase.getInstance("https://androidproje-36714-default-rtdb.europe-west1.firebasedatabase.app/").getReference();
        String userId = user.getUid();

        mReference.child("Kullanicilar").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String accountType = dataSnapshot.child("AccountType").getValue(String.class);
                    if (accountType != null) {
                        switch (accountType) {
                            case "Öğrenci":
                                Intent studentIntent = new Intent(Login.this, OgrenciActivity.class);
                                studentIntent.putExtra("userId", userId);
                                startActivity(studentIntent);
                                finish();
                                break;
                            case "Akademisyen":
                                Intent academicIntent = new Intent(Login.this, AkademisyenActivity.class);
                                academicIntent.putExtra("userId", userId);
                                startActivity(academicIntent);
                                finish();
                                break;
                            case "Admin":
                                Intent adminIntent = new Intent(Login.this, AdminActivity.class);
                                startActivity(adminIntent);
                                finish();
                                break;
                            default:
                                break;
                        }
                    }
                } else {
                    Toast.makeText(Login.this, "Kullanıcı verisi bulunamadı", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("LoginActivity", "Veritabanı hatası: " + databaseError.getMessage());
                Toast.makeText(Login.this, "Veritabanı hatası", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

