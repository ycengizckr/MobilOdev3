package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class AkademisyenActivity extends AppCompatActivity {
    String[] kategoriler = {"Profil arama", "Bilgilerim", "Şifre Değiştir", "Derslerim"};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainscreen);

        Intent intent = getIntent();
        String userId = intent.getStringExtra("userId");

        ListView listView = findViewById(R.id.listView);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(AkademisyenActivity.this, android.R.layout.simple_list_item_1, kategoriler);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selected = kategoriler[position];
                switch (selected){
                    case "Profil arama":
                        Intent searchIntent = new Intent(AkademisyenActivity.this, SearchPerson.class);
                        startActivity(searchIntent);
                        break;

                    case "Bilgilerim":
                        Intent profileIntent = new Intent(AkademisyenActivity.this, Profile.class);
                        startActivity(profileIntent);
                        break;

                    case "Şifre Değiştir":
                        Intent chancePassword = new Intent(AkademisyenActivity.this, ChangePassword.class);
                        startActivity(chancePassword);
                        break;

                    case "Derslerim":
                        Intent courseIntent = new Intent(AkademisyenActivity.this, AkademisyenCourse.class);
                        courseIntent.putExtra("userId", userId);
                        startActivity(courseIntent);
                        break;
                }
            }
        });

    }
}