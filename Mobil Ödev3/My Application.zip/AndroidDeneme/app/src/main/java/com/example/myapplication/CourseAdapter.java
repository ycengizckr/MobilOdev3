package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.CourseViewHolder> {

    private List<Course> courseList;
    private OnItemClickListener listener;

    public CourseAdapter(List<Course> courseList) {
        this.courseList = courseList;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public CourseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.courseview, parent, false);
        return new CourseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseViewHolder holder, int position) {
        Course course = courseList.get(position);
        holder.courseCodeText.setText(course.getCourseId());
        holder.courseNameText.setText(course.getCourseName());
        holder.groupNoText.setText(course.getGroupName());
        holder.startDateText.setText(course.getStartDate());
        holder.endDateText.setText(course.getEndDate());
    }

    @Override
    public int getItemCount() {
        return courseList.size();
    }

    public class CourseViewHolder extends RecyclerView.ViewHolder {
        TextView courseCodeText;
        TextView courseNameText;
        TextView groupNoText;
        TextView startDateText;
        TextView endDateText;

        public CourseViewHolder(@NonNull View itemView) {
            super(itemView);
            courseCodeText = itemView.findViewById(R.id.courseCodeText);
            courseNameText = itemView.findViewById(R.id.courseNameText);
            groupNoText = itemView.findViewById(R.id.groupNoText);
            startDateText = itemView.findViewById(R.id.startDateText);
            endDateText = itemView.findViewById(R.id.endDateText);

            // Set click listener on item view
            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && listener != null) {
                    listener.onItemClick(courseList.get(position).getCourseId(), courseList.get(position).getGroupName());
                }
            });
        }
    }

    // Interface for item click listener
    public interface OnItemClickListener {
        void onItemClick(String courseId, String groupNumber);
    }
}