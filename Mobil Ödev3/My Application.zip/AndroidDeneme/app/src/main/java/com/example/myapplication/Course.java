package com.example.myapplication;

public class Course {
    private String courseId;
    private String courseName;
    private String groupName;
    private String startDate;
    private String endDate;

    public Course(String courseId, String courseName, String groupName, String startDate, String endDate) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.groupName = groupName;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}