    package com.example.myapplication;

    import android.app.DatePickerDialog;
    import android.content.Intent;
    import android.os.Bundle;
    import android.util.Log;
    import android.view.View;
    import android.widget.ArrayAdapter;
    import android.widget.Button;
    import android.widget.DatePicker;
    import android.widget.EditText;
    import android.widget.LinearLayout;
    import android.widget.NumberPicker;
    import android.widget.Spinner;
    import android.widget.Toast;

    import androidx.annotation.NonNull;
    import androidx.annotation.Nullable;
    import androidx.appcompat.app.AppCompatActivity;

    import com.google.firebase.database.DataSnapshot;
    import com.google.firebase.database.DatabaseError;
    import com.google.firebase.database.DatabaseReference;
    import com.google.firebase.database.FirebaseDatabase;
    import com.google.firebase.database.Query;
    import com.google.firebase.database.ValueEventListener;

    import java.util.ArrayList;
    import java.util.Calendar;
    import java.util.GregorianCalendar;
    import java.util.List;

    public class CourseRegister extends AppCompatActivity {

        Button ekleButton;
        EditText courseName, courseID, startDate, endDate, groupCount;
        LinearLayout groupAcademiciansLayout;
        DatabaseReference mDatabase;
        List<String> akademisyenIsimleri = new ArrayList<>();

        @Override
        protected void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.courseregister);

            ekleButton = findViewById(R.id.addCourse_Button);
            courseName = findViewById(R.id.CourseName_text);
            courseID = findViewById(R.id.CourseId_text);
            startDate = findViewById(R.id.startDateEditText);
            endDate = findViewById(R.id.endDateEditText);
            groupCount = findViewById(R.id.groupCountEditText);
            groupAcademiciansLayout = findViewById(R.id.groupAcademiciansLayout);

            getAkademisyen();

            startDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDatePickerDialog(startDate, "01/01/2001");
                }
            });

            endDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDatePickerDialog(endDate, startDate.getText().toString());
                }
            });

            groupCount.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        addGroupAcademiciansEditTexts(Integer.parseInt(groupCount.getText().toString()));
                    }
                }
            });

            ekleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DatabaseReference databaseReference = FirebaseDatabase.getInstance("https://androidproje-36714-default-rtdb.europe-west1.firebasedatabase.app/").getReference("Dersler");
                    String courseNameText = courseName.getText().toString();
                    String courseIDText = courseID.getText().toString();
                    String startDateText = startDate.getText().toString();
                    String endDateText = endDate.getText().toString();
                    String groupCountText = groupCount.getText().toString();

                    databaseReference.child(courseIDText).child("DersAdi").setValue(courseNameText);
                    databaseReference.child(courseIDText).child("BaslangicTarihi").setValue(startDateText);
                    databaseReference.child(courseIDText).child("BitisTarihi").setValue(endDateText);
                    databaseReference.child(courseIDText).child("GrupSayisi").setValue(groupCountText);

                    int groupCount = Integer.parseInt(groupCountText);

                    for (int i = 0; i < groupCount; i++) {
                        Spinner spinner = (Spinner) groupAcademiciansLayout.getChildAt(i);
                        String selectedAcademician = spinner.getSelectedItem().toString();
                        databaseReference.child(courseIDText).child("Gruplar").child("Grup" + (i + 1)).child("Akademisyen").child("Isim").setValue(selectedAcademician);
                    }

                    Toast.makeText(getApplicationContext(), "Ders başarıyla kaydedildi!", Toast.LENGTH_SHORT).show();
                }
            });



        }

        private void getAkademisyen() {
            mDatabase = FirebaseDatabase.getInstance("https://androidproje-36714-default-rtdb.europe-west1.firebasedatabase.app/").getReference();
            mDatabase.child("Kullanicilar").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    akademisyenIsimleri.clear();

                    for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                        String accountType = childSnapshot.child("AccountType").getValue(String.class);
                        if (accountType != null && accountType.equals("Akademisyen")) {
                            String adi = childSnapshot.child("Adi").getValue(String.class);
                            String soyAdi = childSnapshot.child("SoyAdi").getValue(String.class);
                            String tamIsim = adi + " " + soyAdi;
                            akademisyenIsimleri.add(tamIsim);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Hata durumunda yapılacak işlemler
                    Toast.makeText(getApplicationContext(), "Veritabanı işlemi iptal edildi", Toast.LENGTH_SHORT).show();
                }
            });
        }

        private void showDatePickerDialog(final EditText editText, final String minDate) {
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(CourseRegister.this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                            String selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                            editText.setText(selectedDate);
                        }
                    }, year, month, dayOfMonth);

            if (!minDate.isEmpty()) {
                String[] parts = minDate.split("/");
                int minYear = Integer.parseInt(parts[2]);
                int minMonth = Integer.parseInt(parts[1]) - 1; // Month 0-indexed olduğu için -1
                int minDay = Integer.parseInt(parts[0]);
                datePickerDialog.getDatePicker().setMinDate(new GregorianCalendar(minYear, minMonth, minDay).getTimeInMillis());
            }

            datePickerDialog.show();
        }

        private void addGroupAcademiciansEditTexts(int grupSayisi) {
            groupAcademiciansLayout.removeAllViews(); // Önceki görünümleri temizle

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, akademisyenIsimleri);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            for (int i = 0; i < grupSayisi; i++) {
                Spinner spinner = new Spinner(this);
                spinner.setAdapter(adapter);
                groupAcademiciansLayout.addView(spinner);
            }
        }

    }
