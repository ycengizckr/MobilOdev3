package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class AkademisyenCourse extends AppCompatActivity {

    private RecyclerView recyclerView;
    String userId;
    private DatabaseReference mReference;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.akademisyencourse);

        recyclerView = findViewById(R.id.courseListLayout);

        Intent intent = getIntent();
        userId = intent.getStringExtra("userId");

        mReference = FirebaseDatabase.getInstance("https://androidproje-36714-default-rtdb.europe-west1.firebasedatabase.app/").getReference();
        getUserFullName();

    }

    private void getUserFullName() {
        mReference.child("Kullanicilar").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String name = dataSnapshot.child("Adi").getValue(String.class);
                    String surname = dataSnapshot.child("SoyAdi").getValue(String.class);
                    String fullName = name + " " + surname;
                    getAllCourse(fullName);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void getAllCourse(String fullname){
        List<Course> courseList = new ArrayList<>();
        mReference.child("Dersler").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot courseSnapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot grupSnapshot : courseSnapshot.child("Gruplar").getChildren()) {
                        String akademisyen = grupSnapshot.child("Akademisyen").child("Isim").getValue(String.class);
                        if (akademisyen != null && akademisyen.contains(fullname)) {
                            String courseId = courseSnapshot.getKey();
                            String courseName = "Dersin adı: " + courseSnapshot.child("DersAdi").getValue(String.class);
                            String groupName = grupSnapshot.getKey();
                            String startDate = "Başlangıç Tarihi: " + courseSnapshot.child("BaslangicTarihi").getValue(String.class);
                            String endDate = "Bitiş Tarihi: " +courseSnapshot.child("BitisTarihi").getValue(String.class);
                            courseList.add(new Course(courseId, courseName, groupName, startDate, endDate));
                        }
                    }
                }
                CourseAdapter adapter = new CourseAdapter(courseList);
                adapter.setOnItemClickListener((courseId, groupNumber )-> {
                    Intent courseIntent = new Intent(AkademisyenCourse.this, CourseEdit.class);
                    courseIntent.putExtra("courseId", courseId);
                    courseIntent.putExtra("groupNumber", groupNumber);
                    courseIntent.putExtra("userId", fullname);
                    startActivity(courseIntent);
                });
                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(AkademisyenCourse.this));
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
}

