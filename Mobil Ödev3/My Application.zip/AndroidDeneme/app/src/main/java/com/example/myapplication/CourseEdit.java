package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CourseEdit extends AppCompatActivity {
    String oldId, userId, groupNumber, courseID;
    Button insertStudent, deleteStudent, editButton;
    EditText courseName, courseId, courseStartDate, courseEndDate, student;
    DatabaseReference mReference;

    boolean canEdit = true;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.courseedit);

        courseName = findViewById(R.id.courseEditName);
        courseId = findViewById(R.id.courseEditID);
        courseStartDate = findViewById(R.id.courseStartDate);
        courseEndDate = findViewById(R.id.courseEndDate);
        student = findViewById(R.id.studentNumber);

        courseName.setEnabled(false);
        courseId.setEnabled(false);
        courseStartDate.setEnabled(false);
        courseEndDate.setEnabled(false);

        insertStudent = findViewById(R.id.insertButton);
        deleteStudent = findViewById(R.id.deleteButton);
        editButton = findViewById(R.id.editButton);

        Intent intent = getIntent();
        courseID = intent.getStringExtra("courseId");
        userId = intent.getStringExtra("userId");
        groupNumber = intent.getStringExtra("groupNumber");
        mReference = FirebaseDatabase.getInstance("https://androidproje-36714-default-rtdb.europe-west1.firebasedatabase.app/").getReference();

        getCourse(courseID);

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit();
            }
        });

        insertStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String studentNumber = student.getText().toString();
                findStudentName(studentNumber);
            }
        });

        deleteStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String studentNumber = student.getText().toString();
                deleteStudent(studentNumber);
            }
        });

        Button selectFileButton = findViewById(R.id.selectFileButton);
        selectFileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectFile(v);
            }
        });

    }

    private void edit() {
        if (canEdit) {
            oldId = courseId.getText().toString();
            editButton.setText("Kaydet");
            courseName.setEnabled(true);
            courseId.setEnabled(true);
            courseStartDate.setEnabled(true);
            courseEndDate.setEnabled(true);
            canEdit = false;
        } else {
            setCourse(oldId);
            editButton.setText("Düzenle");
            courseName.setEnabled(false);
            courseId.setEnabled(false);
            courseStartDate.setEnabled(false);
            courseEndDate.setEnabled(false);
            canEdit = true;
        }
    }

    private void getCourse(String courseID) {
        mReference.child("Dersler").child(courseID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String courseNameStr = dataSnapshot.child("DersAdi").getValue(String.class);
                    String courseStartDateStr = dataSnapshot.child("BaslangicTarihi").getValue(String.class);
                    String courseEndDateStr = dataSnapshot.child("BitisTarihi").getValue(String.class);

                    courseName.setText(courseNameStr);
                    courseId.setText(courseID);
                    courseStartDate.setText(courseStartDateStr);
                    courseEndDate.setText(courseEndDateStr);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle any errors
            }
        });
    }

    private void setCourse(String oldId) {
        String newName = courseName.getText().toString();
        String newId = courseId.getText().toString();
        String newStartDate = courseStartDate.getText().toString();
        String newEndDate = courseEndDate.getText().toString();

        DatabaseReference courseRef = mReference.child("Dersler");

        DatabaseReference newCourseRef = courseRef.child(newId);
        newCourseRef.child("DersAdi").setValue(newName);
        newCourseRef.child("BaslangicTarihi").setValue(newStartDate);
        newCourseRef.child("BitisTarihi").setValue(newEndDate);

        courseRef.child(oldId).child("DersAdi").setValue(newName);

        if (!oldId.equals(newId)) {
            moveGroups(oldId, newId);
        }
    }

    private void moveGroups(String oldId, String newId) {
        mReference.child("Dersler").child(oldId).child("Gruplar").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot groupSnapshot : dataSnapshot.getChildren()) {
                    String groupName = groupSnapshot.getKey();
                    mReference.child("Dersler").child(newId).child("Gruplar").child(groupName).setValue(groupSnapshot.getValue());
                }
                // Eski dersin grupları taşındıktan sonra eski ders siliniyor
                mReference.child("Dersler").child(oldId).removeValue();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle any errors
            }
        });
    }

    private void findStudentName(String studentNumber) {
        mReference.child("Kullanicilar").orderByChild("Numarasi").equalTo(studentNumber).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        String studentFirstName = userSnapshot.child("Adi").getValue(String.class);
                        String studentLastName = userSnapshot.child("SoyAdi").getValue(String.class);
                        String studentFullName = studentFirstName + " " + studentLastName;
                        insertStudent(studentNumber, studentFullName);
                    }
                } else {
                    Toast.makeText(CourseEdit.this, "Öğrenci bulunamadı", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle any errors
            }
        });
    }

    private void insertStudent(String studentNumber, String studentFullName) {
        DatabaseReference courseRef = mReference.child("Dersler").child(courseID).child("Gruplar").child(groupNumber).child("Öğrenciler");

        courseRef.child(studentNumber).setValue(studentFullName)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(CourseEdit.this, "Öğrenci başarıyla eklendi", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(CourseEdit.this, "Öğrenci eklenirken hata oluştu", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void deleteStudent(String studentNumber) {
        DatabaseReference courseRef = mReference.child("Dersler").child(courseID).child("Gruplar").child(groupNumber).child("Öğrenciler");

        courseRef.child(studentNumber).removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(CourseEdit.this, "Öğrenci başarıyla silindi", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(CourseEdit.this, "Öğrenci silinirken hata oluştu", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();
                try {
                    InputStream inputStream = getContentResolver().openInputStream(uri);
                    addStudentsFromCSV(inputStream);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void selectFile(View view) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*"); // Tüm dosya türlerini seçilebilir yap
        startActivityForResult(intent, 1); // Dosya seçme işlemini başlat ve sonucu beklemek için startActivityForResult kullan
    }
    private void addStudentsFromCSV(InputStream inputStream) {
        BufferedReader okuyucu = new BufferedReader(new InputStreamReader(inputStream));
        String satır;
        try {
            while ((satır = okuyucu.readLine()) != null) {
                String studenNo = satır.trim();
                findStudentName(studenNo);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }



}